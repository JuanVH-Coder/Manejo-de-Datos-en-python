import pandas as pd
from scipy.stats import skew, kurtosis
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import LabelEncoder
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge


# Cargar el archivo CSV
file_path = "semana3/Data_Reto3.csv"
data = pd.read_csv(file_path, delimiter=';')

# Mostrar las primeras filas para verificar que se cargó correctamente
print(data.head())

# Crear un DataFrame vacío para almacenar las filas descartadas
descartados = pd.DataFrame(columns=data.columns)

# Eliminar las filas donde la columna 'salary' no contenga un valor numérico
filas_descartadas_salary = data[pd.to_numeric(data['salary'], errors='coerce').isna()]

# Almacenar las filas descartadas en el DataFrame 'descartados'
descartados = pd.concat([descartados, filas_descartadas_salary])

# Eliminar las filas descartadas del DataFrame original
data = data.drop(filas_descartadas_salary.index)

# Eliminar las filas donde la columna 'salary_in_usd' no contenga un valor numérico
filas_descartadas_salary_usd = data[pd.to_numeric(data['salary_in_usd'], errors='coerce').isna()]

# Almacenar las filas descartadas en el DataFrame 'descartados'
descartados = pd.concat([descartados, filas_descartadas_salary_usd])

# Eliminar las filas descartadas del DataFrame original
data = data.drop(filas_descartadas_salary_usd.index)

data['salary'] = data['salary'].astype(int)
data['salary_in_usd'] = data['salary_in_usd'].astype(int)

# Iterar sobre las columnas que se deben verificar
columnas_verificar = ['employment_type', 'work_setting', 'company_location', 'company_size','job_category']

for columna in columnas_verificar:
    # Eliminar las filas donde la columna contenga un valor numérico
    filas_descartadas = data[pd.to_numeric(data[columna], errors='coerce').notna()]
    
    # Almacenar las filas descartadas en el DataFrame 'descartados'
    descartados = pd.concat([descartados, filas_descartadas])
    
    # Eliminar las filas descartadas del DataFrame original
    data = data.drop(filas_descartadas.index)

# Mostrar las primeras filas después de la limpieza
print(data.head())

# Mostrar las filas descartadas
descartados = descartados.sort_index()
print(descartados.head())

#guardar archivos
#data.to_csv("semana3/data_cleaned.csv", index=False)
# descartados.to_csv("data_discarded.csv", index=False)

# Definir la columna a analizar
columna_a_analizar = 'salary_in_usd'



#################################################

# Definir las características que se utilizarán para predecir el salario en USD
features = [ 'work_setting','salary_currency','job_title', 'job_category', 'experience_level', 'company_location' ,'company_size']

# Crear un DataFrame con las características seleccionadas y la variable objetivo (salario_in_usd)
X = data[features]
y = data[columna_a_analizar]

# Codificar variables categóricas utilizando One-Hot Encoding
X = pd.get_dummies(X)
# Normalizar características
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Dividir los datos en conjuntos de entrenamiento y prueba
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.1, random_state=100)

# Inicializar y entrenar el modelo de regresión lineal con regularización Ridge
alpha = 0.01  # Parámetro de regularización
model = Ridge(alpha=alpha)
model.fit(X_train, y_train)

# Realizar predicciones
predicciones_train = model.predict(X_train)
predicciones_test = model.predict(X_test)

# Evaluar el rendimiento del modelo
rmse_train = mean_squared_error(y_train, predicciones_train, squared=False)
rmse_test = mean_squared_error(y_test, predicciones_test, squared=False)
r2_train = r2_score(y_train, predicciones_train)
r2_test = r2_score(y_test, predicciones_test)

# Mostrar resultados
print("Error cuadrático medio (RMSE) - Conjunto de entrenamiento:", rmse_train)
print("Error cuadrático medio (RMSE) - Conjunto de prueba:", rmse_test)
print("Coeficiente de determinación (R cuadrado) - Conjunto de entrenamiento:", r2_train)
print("Coeficiente de determinación (R cuadrado) - Conjunto de prueba:", r2_test)
###################################################

# Seleccionar características relevantes y la variable objetivo
X = pd.get_dummies(data['experience_level'])  # Codificar variables categóricas utilizando One-Hot Encoding
y = data['salary_in_usd']

# Dividir los datos en conjuntos de entrenamiento y prueba
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Inicializar y entrenar el modelo de regresión lineal con regularización Ridge
alpha = 0.01  # Parámetro de regularización
modelo = Ridge(alpha=alpha)
modelo.fit(X_train, y_train)

# Realizar predicciones
predicciones_train = modelo.predict(X_train)
predicciones_test = modelo.predict(X_test)

# Evaluar el rendimiento del modelo
rmse_train = mean_squared_error(y_train, predicciones_train, squared=False)
rmse_test = mean_squared_error(y_test, predicciones_test, squared=False)
r2_train = r2_score(y_train, predicciones_train)
r2_test = r2_score(y_test, predicciones_test)

# Mostrar resultados
print("Análisis de experiencia laborales vs salario en USD")
print("Error cuadrático medio (RMSE) - Conjunto de prueba:", rmse_test)
print("Coeficiente de determinación (R cuadrado) - Conjunto de prueba:", r2_test)

# Obtener los nombres de las columnas como etiquetas en el eje x
etiquetas_x = X.columns
# Crear el gráfico de dispersión
plt.figure(figsize=(12, 6))
for i, etiqueta in enumerate(etiquetas_x):
    # Seleccionar solo los puntos donde el nivel de experiencia es verdadero (True)
    x_values = [i] * len(X[X[etiqueta]])
    y_values = y[X[etiqueta]]
    plt.scatter(x_values, y_values, label=etiqueta, alpha=0.5)

# Agregar la línea de regresión lineal
predicciones = modelo.predict(X)  # Realizar predicciones
plt.plot(predicciones, label='Predicción', color='red')

plt.title('Salario en USD vs. Nivel de Experiencia')
plt.xlabel('Nivel de Experiencia')
plt.ylabel('Salario en USD')
plt.grid(True)
plt.xticks(ticks=range(len(etiquetas_x)), labels=etiquetas_x, rotation=45, ha='right')
plt.legend()
plt.tight_layout()
plt.show()